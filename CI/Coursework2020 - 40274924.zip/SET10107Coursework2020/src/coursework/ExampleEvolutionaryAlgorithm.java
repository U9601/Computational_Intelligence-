package coursework;

import java.util.ArrayList;
import java.util.Collections;
import java.util.concurrent.ThreadLocalRandom;

import model.Fitness;
import model.Individual;
import model.LunarParameters.DataSet;
import model.NeuralNetwork;

/**
 * Implements a basic Evolutionary Algorithm to train a Neural Network
 * 
 * You Can Use This Class to implement your EA or implement your own class that extends {@link NeuralNetwork} 
 * 
 */
public class ExampleEvolutionaryAlgorithm extends NeuralNetwork {
	

	/**
	 * The Main Evolutionary Loop
	 */
	@Override
	public void run() {		
		//Initialise a population of Individuals with random weights
		population = initialise();

		//Record a copy of the best Individual in the population
		best = getBest();
		System.out.println("Best From Initialisation " + best);

		/**
		 * main EA processing loop
		 */		
		
		while (evaluations < Parameters.maxEvaluations) {

			/**
			 * this is a skeleton EA - you need to add the methods.
			 * You can also change the EA if you want 
			 * You must set the best Individual at the end of a run
			 * 
			 */

			
			// 
			Individual parent1 =  tournamentSelection(); 
			Individual parent2 = tournamentSelection();
			//Individual parent1 = rouletteWheelSelection();
			//Individual parent2 = rouletteWheelSelection();
			ArrayList<Individual> children = new ArrayList<Individual>();
			// Generate a child by crossover. Not Implemented
		// children = crossover(parent1, parent2);
			//children = two_pt_crossover(parent1, parent2);
		   children = uniformCrossover(parent1, parent2);
			
			//mutate the offspring
			//mutate(children);
		    creepMutation(children);
		    //shuffleMutate(children);
		   // scrambleMutate(children);			
			// Evaluate the children
			evaluateIndividuals(children);			
			
			// Replace children in population
			//replace(children);
			replaceFitness(children);
			//sawTooth();

			// check to see if the best has improved
			best = getBest();
			
			// Implemented in NN class. 
			outputStats();
			
			//Increment number of completed generations			
		}

		//save the trained network to disk
		saveNeuralNetwork();
	}

	

	/**
	 * Sets the fitness of the individuals passed as parameters (whole population)
	 * 
	 */
	private void evaluateIndividuals(ArrayList<Individual> individuals) {
		for (Individual individual : individuals) {
			individual.fitness = Fitness.evaluate(individual, this);
		}
	}


	/**
	 * Returns a copy of the best individual in the population
	 * 
	 */
	private Individual getBest() {
		best = null;
		for (Individual individual : population) {
			if (best == null) {
				best = individual.copy();
			} else if (individual.fitness < best.fitness) {
				best = individual.copy();
			}
		}
		return best;
	}
	
	//Just a slightly different getBest Method which I had lying around
	private Individual getBest2(ArrayList<Individual> aPopulation) {
		double bestFitness = Double.MAX_VALUE;
		Individual best = null;
		for(Individual individual : aPopulation){
			if(individual.fitness < bestFitness || best == null){
				best = individual;
				bestFitness = best.fitness;
			}
		}
		return best;
	}


	/**
	 * Generates a randomly initialised population
	 * 
	 */
	private ArrayList<Individual> initialise() {
		population = new ArrayList<>();
		for (int i = 0; i < Parameters.popSize; ++i) {
			//chromosome weights are initialised randomly in the constructor
			Individual individual = new Individual();
			population.add(individual);
		}
		evaluateIndividuals(population);
		return population;
	}

	/**
	 * Selection --
	 * 
	 * NEEDS REPLACED with proper selection this just returns a copy of a random
	 * member of the population
	 */
	/*private Individual select() {		
		Individual parent = population.get(Parameters.random.nextInt(Parameters.popSize));
		return parent.copy();
	}*/
	
	//Tournament Selection
	private Individual tournamentSelection() {
		//Puts tournaments together and picks a parent the best fitness out of them 
		ArrayList<Individual> candidates = new ArrayList<Individual>();
		for(int i = 0; i < Parameters.tournamentSize; i++){
			candidates.add(population.get(Parameters.rnd.nextInt(population.size())));
		}
		return getBest2(candidates).copy();
	}
	

	//Roulette Wheel Selection
	private Individual rouletteWheelSelection(){
		Individual parent = new Individual();
		double totalFitness = 0;
		
		//Gets the total fitness of every individual in the environment
		for(int i = 0; i < population.size(); i++){
			totalFitness += population.get(i).fitness;
		}
		
		double random = ThreadLocalRandom.current().nextDouble(0, totalFitness);
		double sum = 0;
		int i = 0;
		//While the sum is less than the random number add to sum until
		// the sum is greater and then choose the index of when that happened
		// as the parent
		while(sum <= random){ 
			sum += population.get(i).fitness;
			i++;
		}
		parent = population.get(i-1);
		
		return parent;
	}


	/**
	 * Crossover / Reproduction
	 * 
	 * NEEDS REPLACED with proper method this code just returns exact copies of the
	 * parents. 
	 */
	/*private ArrayList<Individual> reproduce(Individual parent1, Individual parent2) {
		ArrayList<Individual> children = new ArrayList<>();
		children.add(parent1.copy());
		children.add(parent2.copy());			
		return children;
	} */
	
	//One point crossover method
	private ArrayList<Individual> crossover(Individual parent1, Individual parent2) {
		
		//If the the next double is greater than the crossover probability then just return a copy of both parents
		ArrayList<Individual> parent = new ArrayList<Individual>();
		if(Parameters.rnd.nextDouble() > Parameters.crossoverProbability){
			  parent.add(parent1.copy());
			  parent.add(parent2.copy());
			return parent;
			
		}
		
		Individual child = new Individual();
		
		//Picks a point where the split should happen between the parents
		int crossoverPoint = Parameters.rnd.nextInt(parent1.chromosome.length);
		
		//until the split add the first parents genes to the child's chromosome
		for(int i = 0; i < crossoverPoint; i++){			
			child.chromosome[i] = parent1.chromosome[i];
		}
		//same with parent 2
		for(int i = crossoverPoint; i < parent2.chromosome.length; i++){			
			child.chromosome[i] = parent2.chromosome[i];
		}
		//Add the child to an arraylist
		ArrayList<Individual> children = new ArrayList<Individual>();
		children.add(child);
		
		return children;
	}
	
	//2 point crossover exactly the same except two splits 
	private ArrayList<Individual> two_pt_crossover(Individual parent1, Individual parent2) {
		
		//If the the next double is greater than the crossover probability then just return a copy of both parents	
		ArrayList<Individual> parent = new ArrayList<Individual>();
		if(Parameters.rnd.nextDouble() > Parameters.crossoverProbability){
			  parent.add(parent1.copy());
			  parent.add(parent2.copy());
			return parent;
			
		}
		Individual child = new Individual();
		
		//Second split is definded here
		int crossoverPoint = Parameters.rnd.nextInt(parent1.chromosome.length);
		int crossoverPoint2 = Parameters.rnd.nextInt(parent2.chromosome.length);
		
		
		//Instead just for one split the code is ran twice
		for(int i = 0; i < crossoverPoint; i++){
			child.chromosome[i] = parent1.chromosome[i];
		}
		
		for(int i = 0; i < crossoverPoint2; i++){
			child.chromosome[i] = parent1.chromosome[i];
		}
		
		for(int i = crossoverPoint; i < parent2.chromosome.length; i++){
			child.chromosome[i] = parent2.chromosome[i];
		}
		
		for(int i = crossoverPoint2; i < parent2.chromosome.length; i++){
			child.chromosome[i] = parent2.chromosome[i];
		}
		ArrayList<Individual> children = new ArrayList<Individual>();
		children.add(child);
		
		return children;
	}
	
	//Uniform crossover
	private ArrayList<Individual> uniformCrossover(Individual parent1, Individual parent2){
		
		//If the the next double is greater than the crossover probability then just return a copy of both parents
		if(Parameters.rnd.nextDouble() > Parameters.crossoverProbability){
			  ArrayList <Individual> parent = new ArrayList <Individual>();
			  parent.add(parent1.copy());
			  parent.add(parent2.copy());
			return parent;
		}
		 int i;
	     double rand = 0;

	     Individual child = new Individual();
	     
	     //50/50 chance that a gene will be passed from either parent to the child
	     //This is for the entire length of the chromosome
	     for(i = 0; i < child.chromosome.length; i++){		
	    	 rand = Math.random();
	    	 if (rand > 0.5) {
                child.chromosome[i] = parent1.chromosome[i];
            } else {
                child.chromosome[i] = parent2.chromosome[i] ;
              }
			}
	     ArrayList <Individual> children = new ArrayList <Individual>();
	     children.add(child);

	        return children;
	}
	
	
	/**
	 * Mutation
	 * 
	 * 
	 */
	/*private void mutate(ArrayList<Individual> individuals) {		
		for(Individual individual : individuals) {
			for (int i = 0; i < individual.chromosome.length; i++) {
				if (Parameters.random.nextDouble() < Parameters.mutateRate) {
					if (Parameters.random.nextBoolean()) {
						individual.chromosome[i] += (Parameters.mutateChange);
					} else {
						individual.chromosome[i] -= (Parameters.mutateChange);
					}
				}
			}
		}		
	}*/
	
	//Creep Mutation
	private void creepMutation(ArrayList<Individual> individuals) {
		//Gets the mutation method
		double mutationRate = Parameters.mutateRate;
		//Loops around all the individuals in the list
		for(Individual individual : individuals) {
			//Picks a random index to use the creep mutation on
			for(int i = 0; i < mutationRate; i++){
				int index = Parameters.rnd.nextInt(individual.chromosome.length);
				//For the first 15000 generations it is more beneficial to have big increments then after that
				//switch to smaller ones
				if (evaluations <= 15000) {
					individual.chromosome[index] += ThreadLocalRandom.current().nextDouble(-100, 100);
				}else {
					individual.chromosome[index] += ThreadLocalRandom.current().nextDouble(-50, 50);
				}
			}
		}
	}

	// Shuffle Mutate
	private void shuffleMutate(ArrayList<Individual> individuals) {
		//Loops around all the individuals in the list
		for(Individual individual : individuals) {
			int size = individual.chromosome.length;
			
			//Gets the mutation rate by picking a random double between 0 and 1 + the mutateRate
			double mutationRate = ThreadLocalRandom.current().nextDouble(0, 1 + Parameters.mutateRate);
			
			//loop around until the random number is less the mutation rate
			for (int i = 0; i < size; i++){
				if(Parameters.rnd.nextInt() < mutationRate){
					//Get a random index that we want to swap
					int swapIndex = ThreadLocalRandom.current().nextInt(0, size - 2);
					if (swapIndex >= i){
						swapIndex++;
					}
					double value = individual.chromosome[i];
					
					//Swap the current index with the swap Index
					individual.chromosome[i] = individual.chromosome[swapIndex];
					individual.chromosome[swapIndex] = value;
				}
			}
		}
	}

	//Scramble mutation Method
	private void scrambleMutate(ArrayList<Individual> individuals){
		for(Individual individual : individuals) {
			//Works by choosing to two random position in the chromosome to do the mutation on
			int size = individual.chromosome.length;
			int pos1 = ThreadLocalRandom.current().nextInt(0, size);
			int pos2 = ThreadLocalRandom.current().nextInt(0, size);
			ArrayList<Double> listChild = new ArrayList<Double>();
			
			//Checks to see position one is less than position two
			if(pos1 >= pos2){
				int temp = pos1;
				pos1 = pos2;
				pos2 =  temp;
			}
			
			
			//Adds all the data to a list of child
			for(int i = pos1; i <= pos2; i++){
				listChild.add(individual.chromosome[i]);
			}
			
			//Shuffles the list and therefore scrambles it 
			Collections.shuffle(listChild);
			
			//Adds the data back to the individual array list
			int j = 0;
			for(int i = pos1; i <= pos2; i++){
				individual.chromosome[i] = listChild.get(j);
				j++;
			}
		}
	}




	
	
	/**
	 * 
	 * Replaces the worst member of the population 
	 * (regardless of fitness)
	 * 
	 */
	private void replace(ArrayList<Individual> individuals) {
		for(Individual individual : individuals) {
			int idx = getWorstIndex();		
			population.set(idx, individual);
		}		
	}
	
	//Replaces worst fitness 
	private void replaceFitness(ArrayList<Individual> individuals) {
		//loops through all individuals in the arraylist and finds the worst
		for(Individual individual : individuals) {
			int idx = getWorstIndex();		
			Individual worst = population.get(idx);
			//puts in our new child and then removes the worst from the population
			population.set(idx, individual);
			population.remove(worst);
		
			
		}		
	}
	
	//Saw Tooth Algorithm
	private void sawTooth(){
		//Checks to see if the max evaluations is divisible by 100 without a remainder and if so checks
		//to see if the population is above the half way point of 20
		if(Parameters.maxEvaluations % 100 == 0){
			if(population.size() >= 20){
				//Get the index of the worst individual in the population
				int index = getWorstIndex();
				Individual worst = population.get(index);
				//Remove the worst
				population.remove(worst);
			}else{
				//If the population is below 20 then reinitialise the population back to 40
				initialise();
			}
		}
	}

	

	/**
	 * Returns the index of the worst member of the population
	 * @return
	 */
	private int getWorstIndex() {
		Individual worst = null;
		int idx = -1;
		for (int i = 0; i < population.size(); i++) {
			Individual individual = population.get(i);
			if (worst == null) {
				worst = individual;
				idx = i;
			} else if (individual.fitness > worst.fitness) {
				worst = individual;
				idx = i; 
			}
		}
		return idx;
	}	

	@Override
	public double activationFunction(double x) {
		/*if (x < -20.0) {
			return -1.0;
		} else if (x > 20.0) {
			return 1.0;
		}
		return Math.tanh(x);*/
		return x;
	}
}
